export default {
    "apiKey": "2e2e72067652e38e86ab40ce3ffc354a"
};